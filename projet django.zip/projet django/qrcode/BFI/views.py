from os import makedirs
from django.shortcuts import render

import json
from json import *
import qrcode 


data = None

def home(request):
    global data
    with open('STB_client.json')as f:
      data_raw= json.load(f) 
      if request.method == 'POST':
          for key in data_raw.keys() : 
            qr = qrcode.QRCode(version = 1, box_size = 10, border = 5) 
            if key==request.POST['data'] :
               data = data_raw[key]               
            qr.add_data(data)                                                           
            qr.make(fit = True)     

            img = qr.make_image(fill = "noir" , back_color = "white")
            img.save("static/image/test.png")
        
      else:
        pass
    return render(request,"home.html",{'data':data})